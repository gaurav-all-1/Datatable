import { SearchListPipe } from './search-list.pipe';

describe('SearchListPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchListPipe();
    expect(pipe).toBeTruthy();
  });
});
